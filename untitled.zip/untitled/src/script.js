// Function to search through tasks based on input
function searchTasks() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase(); // Get search input
    const taskSections = document.querySelectorAll('.taskSection'); // Select all task sections

    // Hide the airdrop list while searching
    document.getElementById('airdropList').style.display = 'none';

    let anyTaskVisible = false; // Track if any task is visible

    taskSections.forEach(section => {
        const tasks = section.querySelectorAll('.task'); // Select all tasks within the section
        let sectionHasVisibleTask = false; // Track if any task in this section is visible

        tasks.forEach(task => {
            const taskName = task.querySelector('h3').textContent.toLowerCase(); // Get the task question
            // Check if the task question matches the search input
            if (taskName.includes(searchInput)) {
                task.style.display = ''; // Show the task if it matches
                sectionHasVisibleTask = true; // Mark the section as having a visible task
            } else {
                task.style.display = 'none'; // Hide the task if it doesn't match
            }
        });

        // Show the section only if it has visible tasks
        section.style.display = sectionHasVisibleTask ? 'block' : 'none';
        anyTaskVisible = anyTaskVisible || sectionHasVisibleTask; // Update anyTaskVisible status
    });

    // If no tasks match, you can show a message or hide the sections completely
    if (!anyTaskVisible) {
        taskSections.forEach(section => section.style.display = 'none'); // Hide all if no task matches
    }
}

// Function to show task answers for the selected airdrop
function showTasks(taskId) {
    // Hide all task sections
    const taskSections = document.querySelectorAll('.taskSection');
    taskSections.forEach(section => section.style.display = 'none');
    
    // Show the selected task section
    const selectedTaskSection = document.getElementById(taskId);
    if (selectedTaskSection) {
        selectedTaskSection.style.display = 'block';
    }

    // Hide the airdrop list
    document.getElementById('airdropList').style.display = 'none';
}

// Function to go back to the airdrop list from the task section
function goBack() {
    // Hide all task sections
    const taskSections = document.querySelectorAll('.taskSection');
    taskSections.forEach(section => section.style.display = 'none');
    
    // Show the airdrop list again
    document.getElementById('airdropList').style.display = 'block';
}

// Function to copy the answer to the clipboard
function copyAnswer(answerId) {
    const answerText = document.getElementById(answerId).textContent; // Get the answer text
    navigator.clipboard.writeText(answerText) // Copy to clipboard
        .then(() => {
            alert('Answer copied to clipboard!'); // Alert user on success
        })
        .catch(err => {
            console.error('Failed to copy: ', err);
        });
}